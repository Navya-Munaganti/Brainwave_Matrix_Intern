package com.hospital.dao;

import com.hospital.models.Appointment;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {
    private static List<Appointment> appointments = new ArrayList<>();

    public static void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public static List<Appointment> getAllAppointments() {
        return appointments;
    }
}
