package com.hospital.dao;

import com.hospital.models.EHR;
import java.util.HashMap;
import java.util.Map;

public class EHRDAO {
    private static Map<Integer, EHR> ehrRecords = new HashMap<>();

    public static void addRecord(EHR record) {
        ehrRecords.put(record.getPatientId(), record);
    }

    public static EHR getRecord(int patientId) {
        return ehrRecords.get(patientId);
    }
}
