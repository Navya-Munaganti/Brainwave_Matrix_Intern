package com.hospital.dao;

import com.hospital.models.Patient;
import com.hospital.utils.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {
    public static void addPatient(Patient patient) {
        try (Connection conn = DatabaseConnection.connect()) {
            String query = "INSERT INTO patients (id, name, age, gender, disease) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, patient.getId());
                stmt.setString(2, patient.getName());
                stmt.setInt(3, patient.getAge());
                stmt.setString(4, patient.getGender());
                stmt.setString(5, patient.getDisease());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        try (Connection conn = DatabaseConnection.connect()) {
            String query = "SELECT * FROM patients";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                while (rs.next()) {
                    Patient patient = new Patient(rs.getInt("id"), rs.getString("name"), rs.getInt("age"),
                            rs.getString("gender"), rs.getString("disease"));
                    patients.add(patient);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patients;
    }
}
