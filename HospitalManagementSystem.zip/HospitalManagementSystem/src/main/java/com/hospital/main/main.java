package com.hospital.main;

import com.hospital.ui.HospitalUI;

public class main {
    public static void main(String[] args) {
        HospitalUI.start();
    }
}
