package com.hospital.models;

public class Bill {
    private int billId;
    private int patientId;
    private double amount;

    public Bill(int billId, int patientId, double amount) {
        this.billId = billId;
        this.patientId = patientId;
        this.amount = amount;
    }

    public int getBillId() { return billId; }
    public int getPatientId() { return patientId; }
    public double getAmount() { return amount; }

    @Override
    public String toString() {
        return "Bill ID: " + billId + ", Patient ID: " + patientId + ", Amount: $" + amount;
    }
}
