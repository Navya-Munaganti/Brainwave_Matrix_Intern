package com.hospital.models;

public class EHR {
    private int patientId;
    private String medicalHistory;

    public EHR(int patientId, String medicalHistory) {
        this.patientId = patientId;
        this.medicalHistory = medicalHistory;
    }

    public int getPatientId() { return patientId; }
    public String getMedicalHistory() { return medicalHistory; }

    public void updateMedicalHistory(String newHistory) {
        this.medicalHistory = newHistory;
    }

    @Override
    public String toString() {
        return "Patient ID: " + patientId + ", Medical History: " + medicalHistory;
    }
}
