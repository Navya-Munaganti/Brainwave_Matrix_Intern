package com.hospital.services;

import com.hospital.dao.AppointmentDAO;
import com.hospital.models.Appointment;
import java.time.LocalDateTime;
import java.util.List;

public class AppointmentService {
    public static void scheduleAppointment(int id, int patientId, int doctorId, LocalDateTime dateTime) {
        Appointment appointment = new Appointment(id, patientId, doctorId, dateTime);
        AppointmentDAO.addAppointment(appointment);
        System.out.println("Appointment Scheduled: " + appointment);
    }

    public static List<Appointment> getAppointments() {
        return AppointmentDAO.getAllAppointments();
    }
}
