package com.hospital.services;

import com.hospital.models.Bill;
import java.util.ArrayList;
import java.util.List;

public class BillingService {
    private static List<Bill> bills = new ArrayList<>();

    public static void generateBill(int billId, int patientId, double amount) {
        Bill bill = new Bill(billId, patientId, amount);
        bills.add(bill);
        System.out.println("Bill Generated: " + bill);
    }

    public static List<Bill> getAllBills() {
        return bills;
    }
}
