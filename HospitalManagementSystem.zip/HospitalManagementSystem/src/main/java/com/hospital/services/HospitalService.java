package com.hospital.services;

import com.hospital.dao.PatientDAO;
import com.hospital.models.Patient;
import java.util.List;

public class HospitalService {

    // Method to register a new patient
    public static void registerPatient(int id, String name, int age, String gender, String disease) {
        Patient newPatient = new Patient(id, name, age, gender, disease);
        PatientDAO.addPatient(newPatient);
        System.out.println("Patient Registered Successfully: " + newPatient);
    }

    // Method to get all patients
    public static List<Patient> getAllPatients() {
        return PatientDAO.getAllPatients();
    }
}
