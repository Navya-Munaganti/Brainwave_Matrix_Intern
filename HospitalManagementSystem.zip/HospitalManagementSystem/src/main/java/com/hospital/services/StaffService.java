package com.hospital.services;

import com.hospital.models.Staff;
import java.util.ArrayList;
import java.util.List;

public class StaffService {
    private static List<Staff> staffList = new ArrayList<>();

    public static void addStaff(int id, String name, String role) {
        Staff staff = new Staff(id, name, role);
        staffList.add(staff);
        System.out.println("Staff Added: " + staff);
    }

    public static List<Staff> getAllStaff() {
        return staffList;
    }
}
