package com.hospital.ui;

import com.hospital.services.HospitalService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class HospitalGUI extends JFrame {
    private JTextField patientIdField;
    private JTextField nameField;
    private JTextField ageField;
    private JTextField genderField;
    private JTextField diseaseField;

    public HospitalGUI() {
        setTitle("Hospital Management System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));

        panel.add(new JLabel("Patient ID:"));
        patientIdField = new JTextField();
        panel.add(patientIdField);

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Age:"));
        ageField = new JTextField();
        panel.add(ageField);

        panel.add(new JLabel("Gender:"));
        genderField = new JTextField();
        panel.add(genderField);

        panel.add(new JLabel("Disease:"));
        diseaseField = new JTextField();
        panel.add(diseaseField);

        JButton submitButton = new JButton("Register Patient");
        submitButton.addActionListener((ActionEvent e) -> {
            int id = Integer.parseInt(patientIdField.getText());
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            String gender = genderField.getText();
            String disease = diseaseField.getText();

            HospitalService.registerPatient(id, name, age, gender, disease);
            JOptionPane.showMessageDialog(this, "Patient Registered Successfully!");
        });

        panel.add(submitButton);
        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new HospitalGUI();
    }
}
