package com.hospital.ui;

import com.hospital.services.*;
import com.hospital.dao.EHRDAO;
import com.hospital.models.*;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HospitalUI {

    public static void start() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Hospital Management System ---");
            System.out.println("1. Register Patient");
            System.out.println("2. Schedule Appointment");
            System.out.println("3. View Appointments");
            System.out.println("4. View EHR");
            System.out.println("5. Generate Bill");
            System.out.println("6. Manage Inventory");
            System.out.println("7. Manage Staff");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear the buffer
            
            switch (choice) {
                case 1:
                    registerPatient(scanner);
                    break;
                case 2:
                    scheduleAppointment(scanner);
                    break;
                case 3:
                    viewAppointments();
                    break;
                case 4:
                    viewEHR(scanner);
                    break;
                case 5:
                    generateBill(scanner);
                    break;
                case 6:
                    manageInventory(scanner);
                    break;
                case 7:
                    manageStaff(scanner);
                    break;
                case 8:
                    System.out.println("Exiting Hospital Management System.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void registerPatient(Scanner scanner) {
        System.out.print("Enter Patient ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Clear the buffer
        
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter Gender: ");
        String gender = scanner.nextLine();
        
        System.out.print("Enter Disease: ");
        String disease = scanner.nextLine();

        HospitalService.registerPatient(id, name, age, gender, disease);
    }

    private static void scheduleAppointment(Scanner scanner) {
        try {
            System.out.print("Enter Appointment ID: ");
            int id = scanner.nextInt();

            System.out.print("Enter Patient ID: ");
            int patientId = scanner.nextInt();

            System.out.print("Enter Doctor ID: ");
            int doctorId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter Appointment Date & Time (yyyy-MM-dd HH:mm): ");
            String dateTime = scanner.nextLine();  // Read full input
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime appointmentTime = LocalDateTime.parse(dateTime, formatter);

            AppointmentService.scheduleAppointment(id, patientId, doctorId, appointmentTime);
        } catch (Exception e) {
            System.out.println("Invalid input! Please use the correct date format: yyyy-MM-dd HH:mm");
        }
    }


    private static void viewAppointments() {
        List<Appointment> appointments = AppointmentService.getAppointments();
        if (appointments.isEmpty()) {
            System.out.println("No appointments found.");
        } else {
            appointments.forEach(System.out::println);
        }
    }

    private static void viewEHR(Scanner scanner) {
        System.out.print("Enter Patient ID to view EHR: ");
        int patientId = scanner.nextInt();
        EHR record = EHRDAO.getRecord(patientId);
        if (record != null) {
            System.out.println(record);
        } else {
            System.out.println("No EHR record found for Patient ID " + patientId);
        }
    }

    private static void generateBill(Scanner scanner) {
        System.out.print("Enter Bill ID: ");
        int billId = scanner.nextInt();
        
        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        
        System.out.print("Enter Amount: ");
        double amount = scanner.nextDouble();

        BillingService.generateBill(billId, patientId, amount);
    }

    private static void manageInventory(Scanner scanner) {
        System.out.print("Enter Item Name: ");
        String itemName = scanner.nextLine();
        
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();

        Inventory inventory = new Inventory(itemName, quantity);
        // In reality, you'd save it to the database, but for now:
        System.out.println("Item added to inventory: " + inventory);
    }

    private static void manageStaff(Scanner scanner) {
        System.out.print("Enter Staff ID: ");
        int staffId = scanner.nextInt();
        scanner.nextLine(); // Clear the buffer
        
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter Role (Doctor/Staff): ");
        String role = scanner.nextLine();
        
        StaffService.addStaff(staffId, name, role);
    }
}
